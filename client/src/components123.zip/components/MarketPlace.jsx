import React from "react";

const PropertyCard = ({ image, title, price, location,explore }) => {
    return (
        <div className="bg-slate-800 rounded-lg shadow-lg overflow-hidden flex flex-col">
            <img src={image} alt={title} className="w-full h-48 object-cover" />
            <div className="p-4 flex flex-row justify-between">
                <div className="">
                    <h3 className="text-lg text-white font-semibold mb-2">{title}</h3>
                    <p className="mb-2 text-white">{location}</p>
                    <p className="text-blue-100 font-bold">Price: {price}</p>
                </div>
                <div className="">
                    <button className="p-3 bg-slate-950 text-white rounded-lg">Explore</button>
                </div>
                
                
            </div>
            
        </div>

    );
};

export default function MarketPlace() {

    const onClick=()=>{

    }

    const properties = [
        {
            image: "https://plus.unsplash.com/premium_photo-1675745330187-a6f001a21abe?q=80&w=1887&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
            title: "Luxury Villa",
            price: "10 ETH",
            location: "Los Angeles, CA",
        },
        {
            image: "https://plus.unsplash.com/premium_photo-1675745329378-5573c360f69f?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
            title: "Modern Apartment",
            price: "8 ETH",
            location: "New York, NY",
        },
        {
            image: "https://images.unsplash.com/photo-1507089947368-19c1da9775ae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
            title: "Beach House",
            price: "15 ETH",
            location: "Miami, FL",
        },
        {
            image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
            title: "Mountain Cabin",
            price: "7 ETH",
            location: "Denver, CO",
        },
        {
            image: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
            title: "Suburban Home",
            price: "5 ETH",
            location: "Austin, TX",
        },
        {
            image: "https://images.unsplash.com/photo-1728049006562-236e5b0dddea?q=80&w=2071&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
            title: "Penthouse Suite",
            price: "20 ETH",
            location: "San Francisco, CA",
        },
    ];
    

    return (
        <div className="min-h-screen p-8">
            <div className="text-center text-blue-100">
                <h1 className="text-4xl sm:text-6xl font-bold mb-4">
                Make Your Best Choice
                </h1>
                <p className="text-lg sm:text-xl font-light mb-8">
                by Choosing Your Favorite Property for Investing
                </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {properties.map((property, index) => (
                    <PropertyCard
                        key={index}
                        image={property.image}
                        title={property.title}
                        price={property.price}
                        location={property.location}
                        explore={onClick}
                    />
                ))}
            </div>
        </div>
    );
}
